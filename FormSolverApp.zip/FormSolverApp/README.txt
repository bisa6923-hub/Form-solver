FORM SOLVER (APK) - Google Forms + Gemini API (gratis)

CARA BUILD (pilih salah satu)

A) Android Studio (PC/laptop)
   1. Ekstrak zip, buka foldernya di Android Studio (File > Open).
   2. Tunggu sync selesai, lalu Build > Build APK(s).
   3. APK ada di app/build/outputs/apk/debug/app-debug.apk

B) GitHub Actions (tanpa install apa pun, gratis)
   1. Buat repository baru di GitHub.
   2. Upload SEMUA isi folder ini (termasuk folder .github dan app).
   3. Buka tab Actions > "Build APK" > Run workflow (atau otomatis saat upload).
   4. Setelah hijau, buka run-nya > bagian Artifacts > unduh FormSolver-APK.
   5. Ekstrak zip artifact, pasang app-debug.apk (izinkan install dari sumber tidak dikenal).

CARA PAKAI
   1. Buka app > Pengaturan > isi API key Gemini (aistudio.google.com/apikey) > Simpan.
   2. Tempel link Google Form > Buka.
   3. Tekan Solve, periksa jawaban, lalu kirim sendiri.
